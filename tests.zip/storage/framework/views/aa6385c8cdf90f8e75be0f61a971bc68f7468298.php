<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
    <!-- Navbar Brand-->
    <?php if(auth()->user()->level == "admin"): ?>
    <a class="navbar-brand ps-3 fw-medium" style="color: #C9D30A;">Sinar Laundry <?php echo e(auth()->user()->cabang->nama); ?></a>
    <?php else: ?>
    <a class="navbar-brand ps-3 fw-medium" style="color: #C9D30A;">Sinar Laundry</a>
    <?php endif; ?>
    <!-- Sidebar Toggle-->
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    <!-- Navbar-->
    <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
        <li class="nav-item dropdown fw-medium fs-55">
            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i> <?php echo e(auth()->user()->nama); ?></a>
            <ul class="dropdown-menu dropdown-menu-end fw-medium" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item fw-medium fs-6" href="<?php echo e(url('profil')); ?>">Profil</a></li>
                <li><hr class="dropdown-divider" /></li>
                <li><a class="dropdown-item fw-medium fs-6" href="<?php echo e(url('logout')); ?>">Logout</a></li>
            </ul>
        </li>
    </ul>
</nav><?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/template/topNav.blade.php ENDPATH**/ ?>