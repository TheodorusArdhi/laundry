<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Layanan dan Harga - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Layanan dan Harga</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Tambah Layanan dan Harga</li>
                        </ol>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form method="POST" action="/postLayanan">
                            <?php echo e(csrf_field()); ?> 

                            <label for="nama" class="fw-semibold form-label mb-0">Nama Layanan</label>
                            <div class="row g-3 align-items-center">
                                <div class="col-3">
                                    <input type="text" id="nama" class="form-control" name="nama" value="<?php echo e(Session::get('nama')); ?>" />
                                </div>
                            </div>

                            <label for="harga" class="fw-semibold form-label mt-2 mb-0">Harga</label>
                            <div class="row g-3 align-items-center">
                                <div class="col-auto">
                                  <label for="harga" class="col-form-label">Rp.</label>
                                </div>
                                <div class="col-2">
                                    <input class="form-control" name="harga" id="harga" type="number" value="<?php echo e(Session::get('harga')); ?>" />
                                </div>
                            </div>

                            <label for="durasi" class="fw-semibold form-label mt-2 mb-0">Waktu Layanan</label>
                            <div class="row g-3 align-items-center">
                                <div class="col-2">
                                    <input type="number" id="durasi" class="form-control" name="durasi" aria-describedby="durasi" value="<?php echo e(Session::get('durasi')); ?>"/>
                                </div>
                                <div class="col-auto">
                                    <label for="durasi" class="col-form-label">Hari</label>
                                  </div>
                            </div>

                            <label for="satuan" class="fw-semibold form-label mt-2 mb-0">Satuan Layanan</label>
                            <div class="row g-3 align-items-center">
                                <div class="col-3">
                                    <select class="form-select" name="satuan" aria-label="Default select example" value="<?php echo e(Session::get('satuan')); ?>">
                                        <option selected disabled>Pilih Satuan</option>
                                        <option value="kg">Kg</option>
                                        <option value="satuan">Satuan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row g-3 mt-1 align-items-center">
                                <div class="col-auto">
                                <a class="btn btn-danger" href="/layanan" role="button">Kembali</a>
                                </div>
                                <div class="col-auto"><button type="submit" class="btn btn-primary btn-block" >Tambah Layanan</button></div>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scriptsAdmin.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/layanan/tambahLayanan.blade.php ENDPATH**/ ?>