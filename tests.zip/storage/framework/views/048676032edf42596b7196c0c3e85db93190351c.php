



<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/template/validate.blade.php ENDPATH**/ ?>