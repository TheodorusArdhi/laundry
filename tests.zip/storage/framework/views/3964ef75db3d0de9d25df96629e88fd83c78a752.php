<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Pengumuman - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Pengumuman</h1>
                        <a class="btn btn-laundry fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('pemilik/pengumuman/create')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Tambah Pengumuman">Tambah <i class="fa-solid fa-plus"></i></a>
                        <a class="btn btn-secondary fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('pemilik/pengumuman/index/siaran')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Siarkan Pengumuman">Siaran <i class="fa-solid fa-bullhorn"></i></a>
                        <div class="card mb-4 mt-2 fs-5">                            
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                <a> <b class="fw-semibold"></b></a>
                            </div>                            
                            <div class="card-body  ">
                                <table id="datatablesSimple">
                                    <thead >
                                        <tr>
                                            <th>No</th>
                                            <th>Judul</th>
                                            <th>Deskripsi</th>
                                            <th>Diskon</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot >
                                        <tr>
                                            <th>No</th>
                                            <th>Judul</th>
                                            <th>Deskripsi</th>
                                            <th>Diskon</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </tfoot>
                                    <?php
                                        $i=1;
                                    ?>
                                    <tbody >
                                        <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($item -> judul); ?></td>
                                            <td><?php echo e($item -> deskripsi); ?></td>
                                            <td><?php echo e($item -> diskon); ?> %</td>
                                            <td>
                                                <?php if($item -> status == "aktif"): ?>
                                                <span class="badge text-bg-success">Aktif</span>
                                                <?php elseif($item -> status == "tidak aktif"): ?>
                                                <span class="badge text-bg-danger">Tidak Akif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-laundry" href=<?php echo e(url('pemilik/pengumuman/'. $item->id_pengumuman.'/edit')); ?> role="button" data-toggle="tooltip" data-placement="top" title="Lihat Detil"><i class="fa-solid fa-magnifying-glass"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/pengumuman/index.blade.php ENDPATH**/ ?>