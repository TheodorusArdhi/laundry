<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Transaksi - Sinar Laundry</title>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Transaksi</h1>

                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item active">Edit Transaksi</li>
                        </ol>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a class="btn btn-warning justify-content-md-end" href=<?php echo e(url('transaksiUnduh/'.$transaksi->id_transaksi.'/unduh')); ?> role="button">Unduh Nota</a>
                        </div>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card shadow-lg border-0 rounded-lg mb-4 mt-3">
                            <form method="POST" action="<?php echo e(route('tambahTransaksiDetailEdit', $transaksi->id_transaksi)); ?> ">
                                <?php echo e(csrf_field()); ?>

                                <label for="namaAdmin" class="fw-semibold form-label mx-3 mt-2 mb-0">Admin</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <input type="text" id="namaAdmin" disabled class="form-control " name="namaAdmin"  value="<?php echo e($transaksi->admin->nama); ?>"/>
                                    </div>
                                </div>
    
                                <label for="no_transaksi" class="fw-semibold form-label mx-3 mt-2 mb-0">Nomor Transaksi</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <input type="text" id="no_transaksi" disabled class="form-control" name="no_transaksi"  value="<?php echo e($transaksi->no_transaksi); ?>"/>
                                    </div>
                                </div>
    
                                <label for="tanggal" class="fw-semibold form-label mx-3 mt-2 mb-0">Tanggal</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <input type="text" id="tanggal" disabled class="form-control" name="tanggal"  value="<?php echo e($transaksi->tgl_masuk); ?>"/>
                                    </div>
                                </div>

                                <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>                                    
                                    <div class="row g-3 align-items-center" >
                                        <div class="col-3 ">
                                        <label for="layanan" class="fw-semibold form-label mx-3 mt-2 mb-0">Layanan</label>
                                            <div class="col mx-3">
                                                <select class="form-control " name="layanan" aria-label="Default select example" value="<?php echo e(Session::get('layanan')); ?>">
                                                    <option selected disabled>Pilih Layanan</option>
                                                    <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id_layanan); ?>"><?php echo e($item->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-3">
                                        <label for="jumlah" class="fw-semibold form-label  mt-2 mb-0">Jumlah</label>
                                            <div class="col mx-3">
                                                <input type="number" id="jumlah" class="form-control" name="jumlah" value="<?php echo e(Session::get('jumlah')); ?>"/>
                                            </div>
                                        </div>

                                        <div class="col-3">
                                            <div class="col-auto"><button type="submit" class="btn btn-primary btn-block" >Tambah</button></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </form>
                            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="card mb-2 mt-3 mx-3">                            
                                <div class="card-header">
                                    <i class="fas fa-table me-1"></i>
                                    <a> <b class="fw-semibold"></b></a>
                                </div>                            
                                <div class="card-body">
                                    <table id="datatablesSimple">
                                        <thead >
                                            <tr>
                                                <th>No</th>
                                                <th>Layanan</th>
                                                <th>Harga</th>
                                                <th>Jumlah</th>
                                                <th>Sub Total</th>
                                                <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                                <th>Aksi</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tfoot >
                                            <tr>
                                                <th>No</th>
                                                <th>Layanan</th>
                                                <th>Harga</th>
                                                <th>Jumlah</th>
                                                <th>Sub Total</th>
                                                <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                                <th>Aksi</th>
                                                <?php endif; ?>
                                            </tr>
                                        </tfoot>
                                        <?php
                                            $i=1;
                                        ?>
                                        <tbody >
                                            <?php $__currentLoopData = $transaksiDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <form method="POST" action="<?php echo e(url('updateTransaksiDetailEdit', $item->id_transaksi_detail)); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="harga" value="<?php echo e($item -> harga); ?>">
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo e($item -> layanan -> nama); ?></td>
                                                    <td><?php echo e(rupiah($item -> harga)); ?></td>
                                                    <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                                    <td><input type="number" id="jumlah" class="form-control" name="jumlah" value="<?php echo e($item -> jumlah); ?>"</td>
                                                    <?php else: ?>
                                                    <td><?php echo e($item -> jumlah); ?></td>
                                                    <?php endif; ?>
                                                    <td><?php echo e(rupiah($item -> subtotal)); ?></td>
                                                    <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                                    <td>
                                                        <button type="submit" class="btn btn-warning btn-block" >Edit</button>
                                                        <a class="btn btn-danger" href=<?php echo e(url('hapusTransaksiDetailEdit', $item->id_transaksi_detail)); ?> data-confirm-delete="true" role="button">Hapus</a>
                                                    </td>
                                                    <?php endif; ?>
                                                </form>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <form method="POST" action="<?php echo e(url('diskonEdit', $transaksi->id_transaksi)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id_transaksi" value="<?php echo e($transaksi->id_transaksi); ?>">
                                <input type="hidden" name="total_harga" value="<?php echo e($transaksi->total_harga); ?>">
                                <label for="diskon" class="fw-semibold form-label mx-3 mt-2 mb-0">Diskon</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <select class="form-control " name="diskon" aria-label="Default select example" aria-describedby="diskon" value="<?php echo e($transaksi->id_pengumuman); ?> " <?php echo e((($transaksi->id_status_transaksi == "7") || (Auth::user()->level == "pengguna") ? 'disabled' : '')); ?>>
                                            <?php if($transaksi->id_pengumuman == null): ?>
                                            <option selected value="" >Pilih Diskon</option>
                                            <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                            <option value="<?php echo e($item->id_pengumuman); ?>" > <?php echo e($item->judul); ?> <?php echo e($item->diskon); ?>% </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                               
                                            <?php else: ?>
                                            <option value="<?php echo e($transaksi->id_pengumuman); ?>" > <?php echo e($transaksi->pengumuman->judul); ?> <?php echo e($transaksi->pengumuman->diskon); ?>% </option>
                                            <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                            <option value="<?php echo e($item->id_pengumuman); ?>" > <?php echo e($item->judul); ?> <?php echo e($item->diskon); ?>% </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                            <option value="" >Hapus Diskon</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                    <div class="col-3">
                                        <div class="col-auto"><button type="submit" class="btn btn-primary btn-block" >Cek</button></div>
                                    </div>    
                                    <?php endif; ?>
                                </div>     
                            </form>
                            <form method="POST" action="<?php echo e(url('updateTransaksi', $transaksi->id_transaksi)); ?>">
                                <?php echo e(csrf_field()); ?> 
                                <label for="nama" class="fw-semibold form-label mx-3 mt-2 mb-0">Nama Pengguna</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <select class="form-control select2" name="nama" aria-label="Default select example" value="<?php echo e(Session::get('nama')); ?>" <?php echo e((($transaksi->id_status_transaksi == "7") || (Auth::user()->level == "pengguna")  ? 'disabled' : '')); ?>>
                                            <option value="<?php echo e($transaksi->user->id_user); ?>"><?php echo e($transaksi->user->nama); ?></option>
                                            <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id_user); ?>"><?php echo e($item->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <label for="total_harga" class="fw-semibold form-label mx-3 mt-2 mb-0">Total Harga</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <input type="text" id="total_harga" disabled class="form-control" name="total_harga"  value="Rp<?php echo e(number_format($transaksi->total_harga, 0, ".", ".")); ?>"/>
                                        <input type="hidden" id="total_harga" class="form-control" name="total_harga"  value="<?php echo e($transaksi->total_harga); ?>"/>
                                    </div>
                                </div>

                                <label for="total_tagihan" class="fw-semibold form-label mx-3 mt-2 mb-0">Total Tagihan</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <?php if($transaksi->id_pengumuman == null): ?>
                                        <input type="text" id="totTag" disabled class="form-control form-control-lg fw-semibold" name="totTag" value="Rp<?php echo e(number_format($transaksi->total_harga, 0, ".", ".")); ?>"/>  
                                        <input type="hidden" id="total_tagihan"  class="form-control" name="total_tagihan" value="<?php echo e($transaksi->total_harga); ?>"/>                                           
                                        <?php else: ?>
                                        <input type="text" id="totTag" disabled class="form-control form-control-lg fw-semibold" name="totTag" value="Rp<?php echo e(number_format($transaksi->total_tagihan, 0, ".", ".")); ?>"/> 
                                        <input type="hidden" id="total_tagihan"  class="form-control" name="total_tagihan" value="<?php echo e($transaksi->total_tagihan); ?>"/>                                                                                       
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <label for="diterima" class="fw-semibold form-label mx-3 mt-2 mb-0">Diterima</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                        <input type="number" id="diterima" class="form-control" name="diterima" value="<?php echo e($transaksi->diterima); ?>"/>
                                        <?php else: ?>
                                        <input type="text" id="ter" class="form-control" disabled name="ter" value="Rp<?php echo e(number_format($transaksi->diterima, 0, ".", ".")); ?>"/>
                                        <input type="hidden" id="diterima" class="form-control" name="diterima" value="<?php echo e($transaksi->diterima); ?>"/>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <label for="kembali" class="fw-semibold form-label mx-3 mt-2 mb-0">Kembali</label>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-3">
                                        <input type="text" id="kembali" disabled class="form-control form-control-lg fw-semibold" name="kembali" value=""/>
                                    </div>
                                </div>

                                <div class="row mx-3 mb-2 g-3 mt-1 align-items-center">
                                    <div class="col-auto">
                                        <a class="btn btn-danger" href="/transaksiAdmin" role="button">Kembali</a>
                                    </div>
                                    <?php if((Auth::user()->level == "admin") && ($transaksi->id_status_transaksi != "7")): ?>
                                    <div class="col-auto"><button type="submit" class="btn btn-primary btn-block" >Simpan</button></div>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>            
            $(document).ready(function() {
                function currencyFormat(x) {
                    return ('Rp'+x).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                }

                let diterima = $('[name="diterima"]');
                let kembali = $('[name="kembali"]');
                let total_tagihan = $('[name="total_tagihan"]');

                kembaliValue = diterima.val() - total_tagihan.val();
                if (kembaliValue < 0) {
                    kembali.val(currencyFormat(0))
                } else {
                    kembali.val(currencyFormat(kembaliValue));   
                }

                diterima.on('input', function() {
                    kembaliValue = diterima.val() - total_tagihan.val();
                    if (kembaliValue < 0) {
                        kembali.val(currencyFormat(0))
                    } else {
                        kembali.val(currencyFormat(kembaliValue));   
                    }
                });
            });            
        </script>
    </body>
</html><?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/editTransaksi.blade.php ENDPATH**/ ?>