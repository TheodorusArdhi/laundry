<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Login - Sinar Laundry</title>
    </head>
    <body class="bg-secondary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Login</h3></div>
                                    <div class="card-body">
                                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <form method="POST" action="<?php echo e(url('login')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-floating mb-3">
                                                <input class="form-control" value="<?php echo e(old('email')); ?>" name="email" type="email" placeholder="nama@email.com" />
                                                <label for="email">Email</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control"  name="password" type="password" placeholder="Password" />
                                                <label for="password">Password</label>
                                            </div>

                                            <div class="mt-4 mb-0">
                                                <div class="d-grid">
                                                    <button type="submit" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" >Login</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-start py-3">
                                        <a class="btn btn-light fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('register/index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Registrasi Akun">Registrasi</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/auth/login.blade.php ENDPATH**/ ?>