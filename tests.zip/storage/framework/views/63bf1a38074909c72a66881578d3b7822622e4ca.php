<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Pengumuman - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Pengumuman</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Edit Pengumuman</li>
                        </ol>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form method="POST" action=" <?php echo e(url('updatePengumuman', $temp->id_pengumuman)); ?>">
                            <?php echo e(csrf_field()); ?> 

                            <label for="judul" class="fw-semibold form-label mx-3 mt-2 mb-0">Judul</label>
                            <div class="row mx-3 g-3 align-items-center">
                                <div class="col-3">
                                    <input type="text" id="judul" class="form-control" name="judul" value="<?php echo e($temp->judul); ?>" />
                                </div>
                            </div>

                            <label for="deskripsi" class="fw-semibold form-label mx-3 mt-2 mb-0">Deskripsi</label>
                            <div class="row mx-3 g-3 align-items-center">
                                <div class="col-3">
                                    <textarea  class="form-control" name="deskripsi" id="deskripsi" ><?php echo e($temp->deskripsi); ?></textarea>
                                </div>
                            </div>

                            <label for="diskon" class="fw-semibold form-label mx-3 mt-2 mb-0">Diskon</label>
                            <div class="row mx-3 g-3 align-items-center">
                                <div class="col-3">
                                    <input type="number" id="diskon" class="form-control" name="diskon" aria-describedby="diskon" value="<?php echo e($temp->diskon); ?>"/>
                                </div>
                                <div class="col-auto">
                                    <label for="diskon" class="col-form-label">%</label>
                                </div>
                            </div>

                            <div class="row g-3 mt-1 align-items-center">
                                <div class="col-auto">
                                <a class="btn btn-danger" href="/pengumuman" role="button">Kembali</a>
                                </div>
                                <div class="col-auto"><button type="submit" class="btn btn-primary btn-block" >Simpan</button></div>
                            </div>
                        </form>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/pengumuman/editPengumuman.blade.php ENDPATH**/ ?>