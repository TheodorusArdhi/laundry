<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Laporan - Sinar Laundry</title>
    </head>
    <body>
        <table class="table table-striped table-bordered table-hover me-2 " id="dtBasicExample">
            <thead >
                <?php
                    $awal = Carbon\Carbon::createFromFormat('Y-m-d', $awal)->format('d-m-Y');
                    $akhir = Carbon\Carbon::createFromFormat('Y-m-d', $akhir)->format('d-m-Y');
                ?>
                <tr >
                    <th class="text-center" colspan="4">Laporan Layanan <?php echo e($awal); ?> - <?php echo e($akhir); ?></th>
                </tr>
                <tr>
                    <th>Layanan</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>                                          
                </tr>  
            </thead>
            <tbody >
                <?php
                    $totalPemasukan = 0;
                ?>
                <?php $__currentLoopData = $layananCount['layanan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr >                                       
                    <th><?php echo e($value -> nama); ?></th>
                    <th><?php echo e(rupiah($value -> harga)); ?></th>
                    <?php if($value -> satuan == "kg"): ?>
                        <th><?php echo e($value -> jumlah); ?> Kg</th>
                    <?php else: ?>
                        <th><?php echo e($value -> jumlah); ?></th>
                    <?php endif; ?>
                    <th><?php echo e(rupiah($value -> pemasukan)); ?></th>
                </tr>
                <?php
                    $totalPemasukan += $value -> pemasukan;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-secondary">
                    <th colspan="3" class="text-center">Total Pemasukan</th>
                    <th><?php echo e(rupiah($totalPemasukan)); ?></th>
                </tr>
            </tbody>                            
        </table>
        <script>
            window.print();
        </script>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/laporan/tabel/tabelLayananPrint.blade.php ENDPATH**/ ?>