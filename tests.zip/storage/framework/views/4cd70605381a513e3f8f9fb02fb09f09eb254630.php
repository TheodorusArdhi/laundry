<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Penyimpanan - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 fs-5">
                        <h1 class="mt-4">Penyimpanan</h1>
                        <a class="btn btn-laundry fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('admin/penyimpanan/create')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Tambah Barang">Tambah <i class="fa-solid fa-plus"></i></a>
                        <?php if(Auth::user()->level == "pemilik"): ?>
                            <form method="POST" action="<?php echo e(url('pemilik/penyimpanan/cabang')); ?>">
                                <?php echo e(csrf_field()); ?> 
                                <label for="cabang" class="fw-semibold form-label mt-2 mb-0">Cabang</label>
                                <div class="row g-3 align-items-center">
                                    <div class="col-3">
                                        <select class="form-select form-select-lg" name="cabang" id="cabang" aria-label="Default select example" value="<?php echo e(Session::get('branch')); ?>">
                                                <option selected ><?php echo e($branch); ?></option>
                                                <option value="semua" >Semua</option>
                                                <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_cabang); ?>"><?php echo e($item->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-3">
                                        <div class="col-auto"><button type="submit" class="btn btn-secondary fw-semibold btn-block" role="button" data-toggle="tooltip" data-placement="top" title="Cek Cabang">Cek</button></div>
                                    </div> 
                                </div>
                            </form>
                        <?php endif; ?>
                        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card mb-4 mt-3 ">                            
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                <a> <b class="fw-semibold"></b></a>
                            </div>                            
                            <div class="card-body  ">
                                <table id="datatablesSimple">
                                    <thead >
                                        <tr>
                                            <th>No</th>
                                            <?php if(Auth::user()->level == "pemilik"): ?>
                                            <th>Cabang</th>
                                            <?php endif; ?>
                                            <th>Nama Barang</th>
                                            <th>Jumlah</th>
                                            <th>Harga</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot >
                                        <tr>
                                            <th>No</th>
                                            <?php if(Auth::user()->level == "pemilik"): ?>
                                            <th>Cabang</th>
                                            <?php endif; ?>
                                            <th>Nama Barang</th>
                                            <th>Jumlah</th>
                                            <th>Harga</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </tfoot>
                                    <?php
                                        $i=1;
                                    ?>
                                    <tbody >
                                        <?php $__currentLoopData = $penyimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($i++); ?></th>
                                            <?php if(Auth::user()->level == "pemilik"): ?>
                                            <th><?php echo e($item -> cabang -> nama); ?></th>
                                            <?php endif; ?>
                                            <th><?php echo e($item -> nama); ?></th>
                                            <th><?php echo e($item -> jumlah); ?></th>
                                            <th><?php echo e(rupiah($item -> harga)); ?></th>
                                            <td>
                                                <a class="btn btn-laundry" href=<?php echo e(url('admin/penyimpanan/'.$item->id_penyimpanan.'/edit')); ?> role="button" data-toggle="tooltip" data-placement="top" title="Lihat Detil"><i class="fa-solid fa-magnifying-glass"></i></a>
                                                <a class="btn btn-danger" href=<?php echo e(url('admin/penyimpanan/'.$item->id_penyimpanan.'/delete')); ?> data-confirm-delete="true" role="button" data-toggle="tooltip" data-placement="top" title="Hapus" ><i class="fa-solid fa-trash"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/penyimpanan/index.blade.php ENDPATH**/ ?>