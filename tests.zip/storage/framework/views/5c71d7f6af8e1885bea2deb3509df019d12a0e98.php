<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Transaksi - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Transaksi</h1>
                        <?php if(Auth::user()->level == "pemilik" || Auth::user()->level == "admin"): ?>
                        <a class="btn btn-laundry fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('admin/transaksi/data')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Tambah Transaksi">Tambah <i class="fa-solid fa-plus"></i></a>
                        <?php endif; ?>
                        <?php if(Auth::user()->level == "admin"): ?>
                            <div class="card mb-4 mt-2 fs-5">                            
                                <div class="card-header">
                                    <i class="fas fa-table me-1"></i>
                                    <a> <b class="fw-semibold"></b></a>
                                </div>                            
                                <div class="card-body body">
                                    <table id="datatablesSimple">
                                        <thead >
                                            <tr>
                                                <th>No</th>
                                                <th>Nomor Transaksi</th>
                                                <th>Nama</th>
                                                <th>Tanggal Masuk</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tfoot >
                                            <tr>
                                                <th>No</th>
                                                <th>Nomor Transaksi</th>
                                                <th>Nama</th>
                                                <th>Tanggal Masuk</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                        <?php
                                            $i=1;
                                        ?>
                                        <tbody >
                                            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr >
                                                <td ><?php echo e($i++); ?></td>
                                                <td><?php echo e($item -> no_transaksi); ?></td>
                                                <td><?php echo e($item -> user -> nama); ?></td>
                                                <td><?php echo e($item -> tgl_masuk -> translatedFormat('l, d F Y')); ?></td>
                                                <td>
                                                    Transaksi: 
                                                    <?php if($item -> id_status_transaksi == "3"): ?>
                                                    <span class="badge text-bg-secondary"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "4"): ?>
                                                    <span class="badge text-bg-info"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "5"): ?>
                                                    <span class="badge text-bg-warning"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "6"): ?>
                                                    <span class="badge text-bg-danger"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "7"): ?>
                                                    <span class="badge text-bg-primary"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "8"): ?>
                                                    <span class="badge text-bg-dark"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php endif; ?>

                                                    Pembayaran: 
                                                    <?php if($item -> id_status_pembayaran == "1"): ?>
                                                    <span class="badge text-bg-success"><?php echo e($item -> statusPembayaran -> nama); ?></span>
                                                    <?php elseif($item -> id_status_pembayaran == "2"): ?>
                                                    <span class="badge text-bg-warning"><?php echo e($item -> statusPembayaran -> nama); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                <a class="btn btn-laundry" href=<?php echo e(url('admin/transaksi/'. $item->id_transaksi.'/edit')); ?> role="button" data-toggle="tooltip" data-placement="top" title="Lihat Detil"><i class="fa-solid fa-magnifying-glass"></i></a>
                                                
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="card mb-4 mt-2 fs-5">                            
                                <div class="card-header">
                                    <i class="fas fa-table me-1"></i>
                                    <a> <b class="fw-semibold"></b></a>
                                </div>                            
                                <div class="card-body body">
                                    <table id="datatablesSimple">
                                        <thead >
                                            <tr>
                                                <th>No</th>
                                                <th>Nomor Transaksi</th>
                                                <th>Cabang</th>
                                                <th>Tanggal Masuk</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tfoot >
                                            <tr>
                                                <th>No</th>
                                                <th>Nomor Transaksi</th>
                                                <th>Cabang</th>
                                                <th>Tanggal Masuk</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                        <?php
                                            $i=1;
                                        ?>
                                        <tbody >
                                            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr >
                                                <td ><?php echo e($i++); ?></td>
                                                <td><?php echo e($item -> no_transaksi); ?></td>
                                                <td><?php echo e($item -> cabang -> nama); ?></td>
                                                <td><?php echo e($item -> tgl_masuk -> translatedFormat('l, d F Y')); ?></td>
                                                <td>
                                                    Transaksi: 
                                                    <?php if($item -> id_status_transaksi == "3"): ?>
                                                    <span class="badge text-bg-secondary"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "4"): ?>
                                                    <span class="badge text-bg-info"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "5"): ?>
                                                    <span class="badge text-bg-warning"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "6"): ?>
                                                    <span class="badge text-bg-danger"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "7"): ?>
                                                    <span class="badge text-bg-primary"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php elseif($item -> id_status_transaksi == "8"): ?>
                                                    <span class="badge text-bg-dark"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                    <?php endif; ?>

                                                    Pembayaran: 
                                                    <?php if($item -> id_status_pembayaran == "1"): ?>
                                                    <span class="badge text-bg-success"><?php echo e($item -> statusPembayaran -> nama); ?></span>
                                                    <?php elseif($item -> id_status_pembayaran == "2"): ?>
                                                    <span class="badge text-bg-warning"><?php echo e($item -> statusPembayaran -> nama); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                <?php if(auth()->user()->level=="pemilik"): ?>
                                                    <a class="btn btn-laundry" href=<?php echo e(url('admin/transaksi/'. $item->id_transaksi.'/edit')); ?> role="button" data-toggle="tooltip" data-placement="top" title="Lihat Detil"><i class="fa-solid fa-magnifying-glass"></i></a>
                                                <?php else: ?>
                                                    <a class="btn btn-laundry" href=<?php echo e(url('pelanggan/transaksi/'. $item->id_transaksi.'/edit')); ?> role="button" data-toggle="tooltip" data-placement="top" title="Lihat Detil"><i class="fa-solid fa-magnifying-glass"></i></a>
                                                <?php endif; ?>
                                                <a class="btn btn-info" href=<?php echo e(url('transaksiNota', $item->id_transaksi)); ?> role="button">Nota</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            body {
                font-family: sans-serif;
                font-size: 2rem;
              }
        </script>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/index.blade.php ENDPATH**/ ?>