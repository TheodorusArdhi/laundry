<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>OTP - Sinar Laundry</title>
    </head>
    <body class="bg-secondary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Loyalty Program</h3></div>
                                    <div class="card-body">

                                        <p class="text-center fw-normal" style="font-size: 1.12rem;">Tekan tombol berikut untuk mendapatkan kode OTP pada WhatsApp Anda</p>
                                        <div class="mt-4 mb-0">
                                            <div class="d-grid">
                                                <a type="button" href="<?php echo e(url('pelanggan/otp/request')); ?>" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" data-toggle="tooltip" data-placement="top" title="Dapatkan Kode OTP">Dapatkan OTP</a>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="card-footer text-start py-3">
                                        <a class="btn btn-danger fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('/profil')); ?>" role="button" >Kembali</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/auth/otp.blade.php ENDPATH**/ ?>