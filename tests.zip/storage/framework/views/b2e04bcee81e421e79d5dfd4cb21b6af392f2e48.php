<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Penyimpanan - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Penyimpanan</h1>
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item active">Tambah Penyimpanan</li>
                        </ol>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card shadow-lg border-0 rounded-lg fs-5">
                            <form method="POST" action="<?php echo e(url('admin/penyimpanan/store')); ?>">
                                <?php echo e(csrf_field()); ?> 
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                        <label for="nama" class="fw-semibold form-label  mt-2 mb-0">Nama Barang</label>
                                        <input type="text" id="nama" class="form-control form-control-lg" name="nama" placeholder="Nama Barang" value="<?php echo e(Session::get('nama')); ?>" />
                                    </div>
                                    <div class="col-6">
                                        <label for="merek" class="fw-semibold form-label  mt-2 mb-0">Merek</label>
                                        <input type="text" id="merek" class="form-control form-control-lg" name="merek" placeholder="Merek Barang" value="<?php echo e(Session::get('merek')); ?>" />
                                    </div>
                                </div>

                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                        <label for="jumlah" class="fw-semibold form-label mt-2 mb-0">Jumlah</label>
                                        <input type="number" id="jumlah" class="form-control form-control-lg" name="jumlah" placeholder="Jumlah Barang" value="<?php echo e(Session::get('jumlah')); ?>" />
                                    </div>
                                    <div class="col-6">
                                        <label for="harga" class="fw-semibold form-label mt-2 mb-0">Harga</label>
                                        <input type="number" id="harga" class="form-control form-control-lg" name="harga" placeholder="Harga Barang" value="<?php echo e(Session::get('harga')); ?>" />
                                    </div>
                                </div>

                                <?php if(Auth::user()->level == "pemilik"): ?>
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                            <label for="cabang" class="fw-semibold form-label mt-2 mb-0">Cabang</label>
                                            <select class="form-select form-select-lg" name="cabang" aria-label="Default select example" value="<?php echo e(Session::get('cabang')); ?>">
                                                <option selected disabled>Pilih Cabang</option>
                                                <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_cabang); ?>"><?php echo e($item->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="row mx-3 mb-2 g-3 mt-1 align-items-center">
                                    <div class="col-auto">
                                    <a class="btn btn-danger fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('admin/penyimpanan')); ?>" role="button">Kembali</a>
                                    </div>
                                    <div class="col-auto"><button type="submit" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" data-toggle="tooltip" data-placement="top" title="Simpan Barang">Simpan</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/penyimpanan/create.blade.php ENDPATH**/ ?>