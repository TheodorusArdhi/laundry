
<table class="table table-bordered table-hover ">
    <thead>
        <tr>
            <th style="font-weight: 600 !important;">No</th>
            <th style="font-weight: 600 !important;">Layanan</th>
            <th style="font-weight: 600 !important;">Harga</th>
            <th style="font-weight: 600 !important;">Jumlah</th>
            <th style="font-weight: 600 !important;">Subtotal</th>
            <th style="font-weight: 600 !important;">Aksi</th>                                        
        </tr>  
    </thead>
    <?php
        $i=1;
    ?>
    <tbody >
        <?php $__empty_1 = true; $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <form method="POST" action="<?php echo e(url('admin/transaksi/detail/'.$item->id_transaksi_detail.'/edit/update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="harga" value="<?php echo e($item -> harga); ?>">
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($item -> layanan -> nama); ?></td>
                <td><?php echo e(rupiah($item -> harga)); ?></td>
                <td><input type="number" step="any" id="jumlah" class="form-control" name="jumlah" value="<?php echo e($item -> jumlah); ?>"</td>
                <td><?php echo e(rupiah($item -> subtotal)); ?></td>
                <td>
                    <button type="submit" class="btn btn-laundry btn-block" data-toggle="tooltip" data-placement="top" title="Edit Layanan"><i class="fa-solid fa-pen"></i></button>
                    <a class="btn btn-danger" href=<?php echo e(url('admin/transaksi/detail/'. $item->id_transaksi_detail.'/edit/delete')); ?> data-confirm-delete="true"><i class="fa-solid fa-trash"></i></a>
                    
                </td>
            </form>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class="text-center" colspan="6">Data tidak ditemukan</td>
            </tr>
        <?php endif; ?> 
    </tbody>                          
</table>

<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/detilAksiEdit.blade.php ENDPATH**/ ?>