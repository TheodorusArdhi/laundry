<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Profil - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Profil</h1>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card shadow-lg border-0 rounded-lg fs-5">
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(url('profil/update')); ?>">
                                    <?php echo e(csrf_field()); ?> 

                                    <div class="row g-3 mx-1 align-items-center">
                                        <div class="col-6 align-self-start">
                                            <label for="nama" class="fw-semibold form-label mt-2 mb-0">Nama</label>
                                            <input type="text" id="nama" class="form-control form-control-lg" name="nama" value="<?php echo e($user->nama); ?>" />
                                        </div>
                                        <div class="col-6">
                                            <label for="email" class="fw-semibold form-label mt-2 mb-0">Email</label>
                                            <input type="email" id="email" class="form-control form-control-lg" name="email" value="<?php echo e($user->email); ?>" />
                                        </div>
                                    </div>
    
                                    <div class="row g-3 mx-1 align-items-center">
                                        <div class="col-6">
                                            <label for="no_telp" class="fw-semibold form-label mt-2 mb-0">Nomor Telepon</label>
                                            <input type="text" id="no_telp" class="form-control form-control-lg" name="no_telp" value="<?php echo e($user->no_telp); ?>" />
                                            <div id="no_telp" class="form-text">
                                                Masukkan nomor tanpa spasi
                                            </div>
                                        </div>
                                        <?php if(auth()->user()->level=="pelanggan" || auth()->user()->level=="anggota"): ?>
                                            <div class="col-auto">
                                                <div class=" form-check form-switch">
                                                    <input class="form-check-input" value="on" name="notifikasi" type="checkbox" role="switch" id="notifikasi" <?php echo e(($user->notifikasi == "on" ? ' checked' : '')); ?>>
                                                    <label class="form-check-label fw-medium" for="notifikasi">Notifikasi WhatsApp</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row g-3 mx-1 mt-1 align-items-center">
                                        <div class="col-auto">
                                            <a type="submit" class="btn btn-secondary btn-block fw-semibold" style="font-size: 1.12rem;" data-toggle="tooltip" data-placement="top" title="v" href="<?php echo e(url('password')); ?>" >Ubah Password</a>
                                            <button type="submit" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" data-toggle="tooltip" data-placement="top" title="Simpan Profil">Simpan</button>
                                        </div>
                                    </div>
                                </form>
                                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>

                        <?php if(auth()->user()->level=="pelanggan" ): ?>
                        <div class="card shadow-lg border-0 rounded-lg fs-5 mt-3 ">
                            <div class="card-body mx-2">
                                <div class="row mt-2">
                                    <div class="col-xl-6">
                                        <div class="card mb-2">
                                            <div class="card-header fw-semibold fs-5">
                                                <i class="fa-solid fa-coins"></i>  Loyalty Program
                                            </div>
                                            <div class="card-body">
                                                <h5 class="card-title fs-4">Dapatkan Potongan Harga Pada Setiap Transaksi Anda!</h5>
                                                <p class="card-text fs-55">Bergabunglah menjadi anggota loyalty program dan dapatkan  potongan harga berupa poin pada setiap kunjungan anda mulai hari ini!</p>
                                                <a href=" <?php echo e(url('pelanggan/otp')); ?>" class="btn btn-laundry fw-semibold fs-4">Gabung Sekarang</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/profil/index.blade.php ENDPATH**/ ?>