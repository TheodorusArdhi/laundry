
<table class="table table-bordered table-hover ">
    <thead class="fw-semibold">
        <tr>
            <th style="font-weight: 600 !important;">No</th>
            <th style="font-weight: 600 !important;">Layanan</th>
            <th style="font-weight: 600 !important;">Harga</th>
            <th style="font-weight: 600 !important;">Jumlah</th>
            <th style="font-weight: 600 !important;">Subtotal</th>                                      
        </tr>  
    </thead>
    <?php
        $i=1;
    ?>
    <tbody >
        <?php $__empty_1 = true; $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($item -> layanan -> nama); ?></td>
            <td><?php echo e(rupiah($item -> harga)); ?></td>
            <td><?php echo e($item -> jumlah); ?></td>
            <td><?php echo e(rupiah($item -> subtotal)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td class="text-center" colspan="6">Data tidak ditemukan</td>
            </tr>
        <?php endif; ?> 
    </tbody>                          
</table><?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/detil.blade.php ENDPATH**/ ?>