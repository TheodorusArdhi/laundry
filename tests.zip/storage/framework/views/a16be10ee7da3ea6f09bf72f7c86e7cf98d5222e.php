<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Laporan - Sinar Laundry</title>
    </head>
    <body>
        <table class="table table-striped table-bordered table-hover me-2 " >
            <thead>
                <?php
                    $awal = Carbon\Carbon::createFromFormat('Y-m-d', $awal)->format('d-m-Y');
                    $akhir = Carbon\Carbon::createFromFormat('Y-m-d', $akhir)->format('d-m-Y');
                ?>
                <tr >
                    <th class="text-center" colspan="7">Laporan Penjualan <?php echo e($awal); ?> - <?php echo e($akhir); ?></th>
                </tr>
                <tr>
                    <th>Nomor Transaksi</th>
                    <th>Cabang</th>
                    <th>Tanggal Masuk</th>
                    <th>Total Harga</th>
                    <th>Diskon</th>
                    <th>Poin Keluar</th>
                    <th>Total Tagihan</th>                                            
                </tr>  
            </thead>
            <tbody >
                <?php
                    $totalTotalHarga = 0;
                    $totalDiskon = 0;
                    $totalPoin = 0;
                    $totalTotalTagihan = 0;
                ?>
                <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr >                                       
                    <th><?php echo e($item -> no_transaksi); ?></th>
                    <th><?php echo e($item -> cabang -> nama); ?></th>
                    <th><?php echo e($item -> tgl_masuk -> translatedFormat('l, d F Y')); ?></th>
                    <th><?php echo e(rupiah($item -> total_harga)); ?></th>
                    <?php
                        $diskon = $item -> total_harga*$item -> diskon/100;
                    ?>
                    <?php if($item -> diskon == 0): ?>
                        <th><?php echo e(rupiah($item -> diskon)); ?></th>
                    <?php else: ?>
                        <th><?php echo e(rupiah($diskon)); ?></th>
                    <?php endif; ?>
                    <th><?php echo e(rupiah($item -> poin_keluar)); ?></th>
                    <th><?php echo e(rupiah($item -> total_tagihan)); ?></th>
                </tr>
                <?php
                    $totalTotalHarga += $item -> total_harga;
                    $totalDiskon += $diskon;
                    $totalPoin += $item -> poin_keluar;
                    $totalTotalTagihan += $item -> total_tagihan;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-secondary">
                    <th colspan="3" class="text-center">Total Keseluruhan</th>
                    <th><?php echo e(rupiah($totalTotalHarga)); ?></th>
                    <th><?php echo e(rupiah($totalDiskon)); ?></th>
                    <th><?php echo e(rupiah($totalPoin)); ?></th>
                    <th><?php echo e(rupiah($totalTotalTagihan)); ?></th>
                </tr>
            </tbody>                            
        </table>
        <script>
            window.print();
        </script>
    </body>
</html><?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/laporan/tabel/tabelPenjualanPrint.blade.php ENDPATH**/ ?>