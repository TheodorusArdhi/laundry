<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Laporan - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 ">
                        <h1 class="mt-4">Laporan Layanan</h1>
                        <form method="POST" action="<?php echo e(url('pemilik/laporan/layanan/tanggal')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <label for="datepicker" class="fw-semibold form-label fs-5 mt-2 mb-0">Tanggal</label>
                            <div class="row g-3 align-items-center">
                                <div class="col-auto">
                                    <div class="input-daterange input-group" id="datepicker">
                                        <input type="text" class="input-sm form-control fs-5" name="awal" value="<?php echo e($awal); ?>" />
                                        <span class="input-group-addon"> s/d </span>
                                        <input type="text" class="input-sm form-control fs-5" name="akhir" value="<?php echo e($akhir); ?>" />
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <div class="col-auto"><button type="submit" class="btn btn-secondary fw-semibold btn-block" role="button" data-toggle="tooltip" data-placement="top" title="Cek Tanggal">Cek</button></div>
                                </div> 
                                <?php if($layananCount != null): ?>
                                <?php
                                    $awal = Carbon\Carbon::createFromFormat('d/m/Y', $awal)->format('Y-m-d');
                                    $akhir = Carbon\Carbon::createFromFormat('d/m/Y', $akhir)->format('Y-m-d');
                                ?>
                                    <div class="col-auto">
                                        <div class="dropdown">
                                            <button class="btn btn-laundry dropdown-toggle fw-semibold" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Export
                                            </button>
                                            <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="<?php echo e(url('pemilik/layanan/export/'.$awal.'/'.$akhir)); ?>">Unduh Excel</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(url('pemilik/layanan/print/'.$awal.'/'.$akhir)); ?>">Cetak PDF</a></li>
                                            </ul>
                                        </div>
                                        
                                    </div>
                                <?php endif; ?>
                            </div>
                        </form>
                        <?php echo $__env->make('template.datePicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card mb-4 mt-3" style="height: 55rem;">                            
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                            </div>                            
                            <div class="card-body table-responsive ">
                                <?php echo $__env->make('laporan.tabel.tabelLayanan', $layananCount, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <script>
                                    $(document).ready(function () {
                                        $('.dtBasicExample').DataTable({
                                            "ordering": false // false to disable sorting (or any other option)
                                        });
                                        $('.dataTables_length').addClass('bs-select');
                                    });
                                </script>
                            </div>
                        </div>     
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/laporan/layanan.blade.php ENDPATH**/ ?>