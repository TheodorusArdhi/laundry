<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Pengumuman - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Pengumuman</h1>
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item active">Edit Pengumuman</li>
                        </ol>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card shadow-lg border-0 rounded-lg fs-5">
                            <form method="POST" action=" <?php echo e(url('pemilik/pengumuman/'. $pengumuman->id_pengumuman.'/update')); ?>">
                                <?php echo e(csrf_field()); ?> 

                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                        <label for="judul" class="fw-semibold form-label mt-2 mb-0">Judul</label>
                                        <input type="text" id="judul" class="form-control form-control-lg" name="judul" placeholder="Judul Pengumuman" value="<?php echo e($pengumuman->judul); ?>" />
                                    </div>
                                    <div class="col-5">
                                        <label for="diskon" class="fw-semibold form-label mt-2 mb-0">Diskon</label>
                                        <input type="number" id="diskon" class="form-control form-control-lg" name="diskon" placeholder="Jumlah Diskon" aria-describedby="diskon" value="<?php echo e($pengumuman->diskon); ?>"/>
                                    </div>
                                    <div class="col-auto align-self-end mb-1">
                                        <label for="diskon" class="col-form-label">%</label>
                                    </div>
                                </div>

                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-12">
                                        <label for="deskripsi" class="fw-semibold form-label mt-2 mb-0">Deskripsi</label>
                                        <textarea  class="form-control form-control-lg" name="deskripsi" id="deskripsi" placeholder="Dskripsi Pengumuman"><?php echo e($pengumuman->deskripsi); ?></textarea>
                                    </div>
                                </div>

                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                        <label for="status" class="fw-semibold form-label mt-2 mb-0">Status</label>
                                        <select class="form-select form-select-lg" name="status" aria-label="Default select example" value="<?php echo e(Session::get('status')); ?>">
                                            <option value="<?php echo e($pengumuman->status); ?>"><?php echo e($pengumuman->status); ?></option>
                                            <option value="aktif">Aktif</option>
                                            <option value="tidak aktif">Tidak Aktif</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mx-3 mb-2 g-3 mt-1 align-items-center">
                                    <div class="col-auto">
                                    <a class="btn btn-danger fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('pemilik/pengumuman')); ?>" role="button">Kembali</a>
                                    </div>
                                    <div class="col-auto"><button type="submit" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" data-toggle="tooltip" data-placement="top" title="Simpan Pengumuman">Simpan</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/pengumuman/edit.blade.php ENDPATH**/ ?>