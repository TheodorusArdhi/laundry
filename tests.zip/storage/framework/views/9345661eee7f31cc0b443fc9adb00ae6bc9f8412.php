<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Poin - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4 fs-5">
                        <h1 class="mt-4">Poin</h1>
                        <?php if(Auth::user()->level == "pemilik" || Auth::user()->level == "admin"): ?>
                            <form method="POST" action="<?php echo e(url('admin/poin/user')); ?>">
                                <?php echo e(csrf_field()); ?> 
                                <div class="row g-3 align-items-center">
                                    <div class="col-3">
                                        <label for="nama" class="fw-semibold form-label mb-0">Pengguna</label>
                                        <select class="form-select form-select-lg select2" name="nama" id="nama" aria-label="Default select example" value="<?php echo e(Session::get('nama')); ?>">      
                                            <?php if($user == "Semua"): ?>
                                                <option selected value="Semua"><?php echo e($user); ?></option>
                                                <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_user); ?>"><?php echo e($item->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($user->id_user); ?>"><?php echo e($user->nama); ?></option>
                                                <option value="Semua" >Semua</option>
                                                <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_user); ?>"><?php echo e($item->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="col-auto align-self-end mb-1">
                                        <div class="col-auto"><button type="submit" class="btn btn-secondary fw-semibold btn-block" role="button" data-toggle="tooltip" data-placement="top" title="Cek Pengguna">Cek</button></div>
                                    </div> 
                                </div>
                            </form>
                            <?php if($user != "Semua"): ?>
                            <h5 class="mb-2 mt-1">Poin : <?php echo e($sum); ?> </h5>
                            <?php endif; ?>
                        <?php else: ?>

                        <?php
                            $poinUser = $poin->sum('jumlah');
                        ?>
                        <h5 class="mb-2">Poin : <?php echo e($poinUser); ?> </h5>
                        <?php endif; ?>

                        <div class="card mb-4 mt-3 ">                            
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                <a> <b class="fw-semibold">Riwayat Poin Transaksi</b></a>
                            </div>                            
                            <div class="card-body  ">
                                <table id="datatablesSimple">
                                    <thead >
                                        <tr>
                                            <th>No</th>
                                            <?php if(Auth::user()->level == "pemilik" || Auth::user()->level == "admin"): ?>
                                            <th>Nama</th>
                                            <?php endif; ?>
                                            <th>Nomor Transaksi</th>
                                            <th>Tanggal Tenggat</th>
                                            <th>Poin</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tfoot >
                                        <tr>
                                            <th>No</th>
                                            <?php if(Auth::user()->level == "pemilik" || Auth::user()->level == "admin"): ?>
                                            <th>Nama</th>
                                            <?php endif; ?>
                                            <th>Nomor Transaksi</th>
                                            <th>Tanggal Tenggat</th>
                                            <th>Poin</th>
                                            <th>Status</th>
                                        </tr>
                                    </tfoot>
                                    <?php
                                        $i=1;
                                    ?>
                                    <tbody >
                                        <?php $__currentLoopData = $poin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <?php if(Auth::user()->level == "pemilik" || Auth::user()->level == "admin"): ?>
                                            <td><?php echo e($item -> user -> nama); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($item -> transaksi -> no_transaksi); ?></td>
                                            <td><?php echo e($item -> tgl_tenggat -> translatedFormat('l, d F Y')); ?></td>
                                            <td><?php echo e($item -> jumlah); ?></td>
                                            <td>
                                                <?php if($item -> status == "aktif"): ?>
                                                <span class="badge text-bg-success">Aktif</span>
                                                <?php elseif($item -> status == "tidak aktif"): ?>
                                                <span class="badge text-bg-danger">Tidak Akif</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/poin.blade.php ENDPATH**/ ?>