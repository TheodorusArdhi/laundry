<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Registrasi - Sinar Laundry</title>
    </head>
    <body class="bg-secondary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Registrasi</h3></div>
                                    <div class="card-body">
                                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <form method="POST" action="<?php echo e(url('register/store')); ?>">
                                            <?php echo e(csrf_field()); ?> 
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="nama" type="text" placeholder="Nama" value="<?php echo e(Session::get('nama')); ?>" />
                                                <label for="nama">Nama</label>
                                            </div>

                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="email" type="email" placeholder="nama@email.com" value="<?php echo e(Session::get('email')); ?>"/>
                                                <label for="email">Email</label>
                                            </div>

                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="no_telp" type="text" placeholder="Nomor Telepon" value="<?php echo e(Session::get('no_telp')); ?>"/>
                                                <label for="noTelp">Nomor Telepon</label>
                                                <div id="no_telp" class="form-text">
                                                    Masukkan nomor tanpa spasi
                                                </div>
                                            </div>
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="password" type="password" placeholder="Password" value="<?php echo e(Session::get('password')); ?>"/>
                                                        <label for="password">Password</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="passwordConfirm" type="password" placeholder="Konfirmasi Password" value="<?php echo e(Session::get('passwordConfirm')); ?>"/>
                                                        <label for="passwordConfirm">Konfirmasi Password</label>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="mt-4 mb-0">
                                                <div class="d-grid">
                                                    <button type="submit" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" role="button" data-toggle="tooltip" data-placement="top" title="Registrasi Akun">Registrasi</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-start py-3">
                                        <a class="btn btn-light fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('login/index')); ?>">Login</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/auth/register.blade.php ENDPATH**/ ?>