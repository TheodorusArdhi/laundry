<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Transaksi - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Transaksi <?php echo e($title); ?></h1>
                        <a class="btn btn-success" href="/tambahTransaksi" role="button">Tambah</a>
                        <div class="card mb-4 mt-2 ">                            
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                <a> <b class="fw-semibold"></b></a>
                            </div>                            
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead >
                                        <tr>
                                            <th>No</th>
                                            <th>Kode Transaksi</th>
                                            <th>Tanggal Masuk</th>
                                            <th>Tanggal Selesai</th>
                                            <th>Nama</th>
                                            <th>Status Transaksi</th>
                                            <th>Status Pembayaran</th>
                                            <th>Harga</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot >
                                        <tr>
                                            <th>No</th>
                                            <th>Kode Transaksi</th>
                                            <th>Tanggal Masuk</th>
                                            <th>Tanggal Selesai</th>
                                            <th>Nama</th>
                                            <th>Status Transaksi</th>
                                            <th>Status Pembayaran</th>
                                            <th>Harga</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </tfoot>
                                    <?php
                                        $i=1;
                                    ?>
                                    <tbody >
                                        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($item -> no_transaksi); ?></td>
                                            <td><?php echo e($item -> tgl_masuk -> translatedFormat('l, d F Y')); ?></td>
                                            <td><?php echo e($item -> tgl_selesai -> translatedFormat('l, d F Y')); ?></td>
                                            <td><?php echo e($item -> user -> nama); ?></td>
                                            <td>
                                                <?php if($item -> id_status_transaksi == "3"): ?>
                                                <span class="badge text-bg-secondary"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                <?php elseif($item -> id_status_transaksi == "4"): ?>
                                                <span class="badge text-bg-info"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                <?php elseif($item -> id_status_transaksi == "5"): ?>
                                                <span class="badge text-bg-warning"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                <?php elseif($item -> id_status_transaksi == "6"): ?>
                                                <span class="badge text-bg-danger"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                <?php elseif($item -> id_status_transaksi == "7"): ?>
                                                <span class="badge text-bg-primary"><?php echo e($item -> statusTransaksi -> nama); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($item -> id_status_pembayaran == "1"): ?>
                                                <span class="badge text-bg-success"><?php echo e($item -> statusPembayaran -> nama); ?></span>
                                                <?php elseif($item -> id_status_pembayaran == "2"): ?>
                                                <span class="badge text-bg-warning"><?php echo e($item -> statusPembayaran -> nama); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(rupiah($item -> total_tagihan)); ?></td>
                                            <td>
                                            <?php if(auth()->user()->level=="admin"): ?>
                                                <a class="btn btn-primary" href=<?php echo e(url('lihatTransaksi', $item->id_transaksi)); ?> role="button">Lihat</a>
                                                <?php if($item->id_status_pembayaran == "2"): ?>
                                                <a class="btn btn-success" href=<?php echo e(url('transaksiLunas', $item->id_transaksi)); ?> role="button">Lunas</a>
                                                <?php endif; ?>
                                                <?php if($item->id_status_pembayaran == "1" && ($item->id_status_transaksi == "4" || $item->id_status_transaksi == "5" || $item->id_status_transaksi == "6")): ?>
                                                <a class="btn btn-info" href=<?php echo e(url('transaksiDiambil', $item->id_transaksi)); ?> role="button">Diambil</a>
                                                <?php endif; ?>
                                                <?php if($item -> id_status_transaksi == "3"): ?>
                                                <a class="btn btn-danger" href=<?php echo e(url('hapusTransaksi', $item->id_transaksi)); ?> data-confirm-delete="true" role="button">Batal</a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->level=="pengguna"): ?>
                                                <a class="btn btn-primary" href=<?php echo e(url('lihatTransaksiPengguna', $item->id_transaksi)); ?> role="button">Lihat</a>
                                                <a class="btn btn-danger" href=<?php echo e(url('lihatTransaksiPengguna', $item->id_transaksi)); ?> role="button">Komplain</a>
                                            <?php endif; ?>
                                            <a class="btn btn-info" href=<?php echo e(url('transaksiNota', $item->id_transaksi)); ?> role="button">Nota</a>
                                            
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/tampilTransaksi.blade.php ENDPATH**/ ?>