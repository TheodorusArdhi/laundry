<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/washing_machine.ico')); ?>" />
    <title>Nota - Sinar Laundry</title>

    <style>
        html,
        body {
            margin: 10px;
            padding: 10px;
            font-family: sans-serif;
        }
        h1,h2,h3,h4,h5,h6,p,span,label {
            font-family: sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 0px !important;
        }
        table thead th {
            height: 28px;
            text-align: left;
            font-size: 16px;
            font-family: sans-serif;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            font-size: 14px;
        }

        .heading {
            font-size: 24px;
            margin-top: 12px;
            margin-bottom: 12px;
            font-family: sans-serif;
        }
        .small-heading {
            font-size: 18px;
            font-family: sans-serif;
        }
        .total-heading {
            font-size: 18px;
            font-weight: 700;
            font-family: sans-serif;
        }
        .mid-heading {
            font-size: 16px;
            font-weight: 700;
            font-family: sans-serif;
        }
        .order-details tbody tr td:nth-child(1) {
            width: 20%;
        }
        .order-details tbody tr td:nth-child(3) {
            width: 20%;
        }

        .text-start {
            text-align: left;
        }
        .text-end {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .company-data span {
            margin-bottom: 4px;
            display: inline-block;
            font-family: sans-serif;
            font-size: 14px;
            font-weight: 400;
        }
        .no-border {
            border: 1px solid #fff !important;
        }
        .bg-primary {
            background-color: #0d6efd;
            color: #fff;
        }

        .bg-primary-light {
            background-color: #eef2f9;
        }

    </style>
</head>
<body>
    <table class="order-details">
        <thead>
            <tr>
                <th colspan="4" class="text-center company-data">
                    <h2>Sinar Laundry</h2>
                    <span>Alamat: Solo</span> <br>
                    <span>Telepon: </span> <br>
                    <span>Instagram: </span> <br>
                </th>
            </tr>
            <tr class="bg-primary">
                <th width="50%" colspan="2">Detail Transaksi</th>
                <th width="50%" colspan="2">Customer</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Nomor Nota</td>
                <td><?php echo e($transaksi->no_transaksi); ?></td>

                <td>Nama</td>
                <td><?php echo e($transaksi->user->nama); ?></td>
            </tr>
            <tr>
                <td>Operator</td>
                <td><?php echo e($transaksi->admin->nama); ?></td>

                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Tanggal Transaksi</td>
                <td><?php echo e($transaksi->created_at-> translatedFormat('l, d F Y H:i')); ?> WIB</td>

                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Status Pembayaran</td>
                <td><?php echo e($transaksi->statusPembayaran->nama); ?></td>

                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>Perkiraan Selesai</td>
                <td><?php echo e($transaksi->tgl_selesai-> translatedFormat('l, d F Y')); ?> <?php echo e($transaksi->created_at-> translatedFormat('H:i')); ?> WIB</td>

                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>

    <table>
        <thead>
            <tr>
                <th class="no-border text-start total-heading" colspan="5">
                    Detail Layanan
                </th>
            </tr>
            <tr class="bg-primary">
                <th>No</th>
                <th>Layanan</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Total</th>
            </tr>
        </thead>
    <?php
        $i=1;
    ?>
        <tbody >
            <?php $__currentLoopData = $transaksiDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($item -> layanan -> nama); ?></td>
                <td><?php echo e(rupiah($item -> harga)); ?></td>
                <?php if($item -> layanan -> satuan == "kg"): ?>
                <td><?php echo e($item -> jumlah); ?> Kg</td>
                <?php else: ?>
                <td><?php echo e($item -> jumlah); ?></td>
                <?php endif; ?>
                <td><?php echo e(rupiah($item -> subtotal)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($transaksi->id_pengumuman != null): ?>
            <tr class="bg-primary-light">
                <td colspan="4" class="mid-heading"><small>Total Harga</small></td>
                <td colspan="1" class="mid-heading"><small><?php echo e(rupiah($transaksi->total_harga)); ?></small></td>
            </tr>
            <tr class="bg-primary-light">
                <td colspan="4" class="mid-heading"><small>Diskon <?php echo e($transaksi->pengumuman->judul); ?> <?php echo e($transaksi->pengumuman->diskon); ?>%</small></td>
                <?php
                $diskon = $transaksi->total_harga - $transaksi->total_tagihan;
                ?>
                <td colspan="1" class="mid-heading"><small>-<?php echo e(rupiah($diskon)); ?></small></td>
            </tr>
            <?php endif; ?>

            <tr class="bg-primary-light">
                <td colspan="4" class="total-heading">Total Tagihan</td>
                <td colspan="1" class="total-heading"><?php echo e(rupiah($transaksi->total_tagihan)); ?></td>
            </tr>
            <tr class="bg-primary-light">
                <td colspan="4" class="mid-heading"><small>Diterima</small></td>
                <td colspan="1" class="mid-heading"><small><?php echo e(rupiah($transaksi->diterima)); ?></small></td>
            </tr>
            <tr class="bg-primary-light">
                <td colspan="4" class="total-heading">Kembali</td>
                <td colspan="1" class="total-heading"><?php echo e(rupiah($transaksi->diterima - $transaksi->total_tagihan)); ?></td>
            </tr>
        </tbody>
    </table>
    <p class="text-center">
        SYARAT DAN KETENTUAN ...
    </p>
    <br>
    <p class="text-center">
        Terima Kasih Telah Menggunakan Layanan Kami - Sinar Laundry
    </p>

</body>
</html><?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/transaksi/nota.blade.php ENDPATH**/ ?>