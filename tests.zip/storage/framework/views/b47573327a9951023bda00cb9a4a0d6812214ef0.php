<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Pengguna - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Pengguna</h1>
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item active">Edit Pengguna</li>
                        </ol>
                        <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="card shadow-lg border-0 rounded-lg fs-5">
                            <form method="POST" action="<?php echo e(url('admin/user/'. $user->id_user.'/update')); ?>">
                                <?php echo e(csrf_field()); ?> 
                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                        <label for="nama" class="fw-semibold form-label mt-2 mb-0">Nama</label>
                                        <input type="text" id="nama" class="form-control form-control-lg" name="nama" placeholder="Nama Pengguna" disabled value="<?php echo e($user->nama); ?>" />
                                    </div>
                                    <div class="col-6">
                                        <label for="no_telp" class="fw-semibold form-label mt-2 mb-0">Nomor Telepon</label>
                                        <input type="text" id="no_telp" class="form-control form-control-lg" name="no_telp" placeholder="Nomor Telepon Pengguna" disabled value="<?php echo e(str_pad(substr($user->no_telp, -4), strlen($user->no_telp), '*', STR_PAD_LEFT)); ?>" />
                                    </div>
                                </div>

                                <div class="row mx-3 g-3 align-items-center">
                                    <div class="col-6">
                                        <label for="email" class="fw-semibold form-label mt-2 mb-0">Email</label>
                                        <input type="email" id="email" class="form-control form-control-lg" placeholder="Email Pengguna" name="email" disabled value="<?php echo e($user->email); ?>" />
                                    </div>
                                    <?php if($user->id_cabang != null): ?>
                                        <div class="col-6">
                                            <label for="cabang" class="fw-semibold form-label mt-2 mb-0">Cabang</label>
                                            <select class="form-select form-select-lg" name="cabang" aria-label="Default select example" value="<?php echo e(Session::get('cabang')); ?>">
                                                <option value="<?php echo e($user->id_cabang); ?>"><?php echo e($user->cabang->nama); ?></option>
                                                <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id_cabang); ?>"><?php echo e($item->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                

                                <input type="hidden" name="level" value="<?php echo e($user->level); ?>">
                                <div class="row mx-3 mb-2 g-3 mt-1 align-items-center">
                                    <?php if(Auth::user()->level == "pemilik"): ?>
                                    <div class="col-auto">
                                        <a class="btn btn-danger fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('pemilik/user')); ?>" role="button">Kembali</a>
                                    </div>
                                    <?php if($user->level == "admin"): ?>
                                        <div class="col-auto"><button type="submit" class="btn btn-laundry btn-block fw-semibold" style="font-size: 1.12rem;" data-toggle="tooltip" data-placement="top" title="Simpan Pengguna">Simpan</button></div>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <div class="col-auto">
                                        <a class="btn btn-danger fw-semibold" style="font-size: 1.12rem;" href="<?php echo e(url('admin/user')); ?>" role="button">Kembali</a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/user/edit.blade.php ENDPATH**/ ?>