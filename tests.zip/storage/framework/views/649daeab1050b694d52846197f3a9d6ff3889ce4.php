<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Ubah Password - SB Admin</title>
        <link rel="icon" type="image/x-icon" href="assets/washing_machine.ico" />
        <link href="css/stylesAdmin.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Ubah Password</h3></div>
                                    <div class="card-body">
                                        <?php if(session('msg')): ?>
                                        <p class="alert alert-danger"><?php echo e(session('msg')); ?></p>
                                        <?php endif; ?>
                                        <?php if(session('success')): ?>
                                        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
                                        <?php endif; ?>
                                        <?php if($errors->any()): ?>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="alert alert-danger"><?php echo e($err); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <form method="POST" action="/postPassword">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-floating mb-3">
                                                <input class="form-control"  name="oldPassword" type="password" placeholder="Password Lama" />
                                                <label for="password">Password Lama</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control"  name="newPassword" type="password" placeholder="Password Baru" />
                                                <label for="password">Password Baru</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control"  name="newPasswordConfirm" type="password" placeholder="Konfirmasi Password Baru" />
                                                <label for="password">Konfirmasi Password Baru</label>
                                            </div>
                                            
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <a class="btn btn-danger" href="/profile">Kembali</a>
                                                <button type="submit" class="btn btn-primary" >Ubah Password</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scriptsAdmin.js"></script>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/password.blade.php ENDPATH**/ ?>