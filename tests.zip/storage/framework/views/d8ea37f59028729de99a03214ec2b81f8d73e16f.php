<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <title>Profil - Sinar Laundry</title>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('template.topNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="layoutSidenav">
            <?php echo $__env->make('template.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Profil</h1>
                        <div class="card shadow-lg border-0 rounded-lg ">
                            <div class="card-body">
                                <?php echo $__env->make('template.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form method="POST" action="/editProfile">
                                    <?php echo e(csrf_field()); ?> 
                                    <div class="form-floating mb-3">
                                        <input class="form-control" name="nama" type="text" value="<?php echo e($user->nama); ?>" />
                                        <label for="nama">Nama</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input class="form-control" name="email" type="email" value="<?php echo e($user->email); ?>" />
                                        <label for="email">Email</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input class="form-control" name="no_telp" type="text" value="<?php echo e($user->no_telp); ?>" />
                                        <label for="noTelp">Nomor Telepon</label>
                                    </div>

                                    <div class="mb-3 form-check form-switch">
                                        <input class="form-check-input" value="on" name="notifikasi" type="checkbox" role="switch" id="notifikasi" <?php echo e(($user->notifikasi == "on" ? ' checked' : '')); ?>>
                                        <label class="form-check-label" for="notifikasi">Notifikasi WhatsApp</label>
                                    </div>

                                    <div class="mt-4 mb-0">
                                        <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                            <a type="submit" class="btn btn-success btn-block" href="/password" >Ubah Password</a>
                                            <button type="submit" class="btn btn-primary btn-block" >Simpan</button>
                                        </div>
                                    </div>
                                </form>
                                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </main>
                <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH D:\Tugas\SEMESTER 8\TA\laundry\resources\views/profile.blade.php ENDPATH**/ ?>